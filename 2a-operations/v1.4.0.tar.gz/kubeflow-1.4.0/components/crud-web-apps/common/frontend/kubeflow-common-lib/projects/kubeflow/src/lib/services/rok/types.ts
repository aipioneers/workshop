import { BackendResponse } from '../backend/types';

export interface RokSettings {
  static_token: string;
  services_url: string;
  url_prefix: string;
}
