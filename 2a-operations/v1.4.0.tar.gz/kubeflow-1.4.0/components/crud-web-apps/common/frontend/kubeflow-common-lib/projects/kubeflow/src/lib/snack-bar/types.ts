export enum SnackType {
  Success,
  Error,
  Warning,
  Info,
}
